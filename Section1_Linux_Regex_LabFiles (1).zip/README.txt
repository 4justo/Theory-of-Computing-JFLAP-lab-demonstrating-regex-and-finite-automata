========================================================
  LAB SAMPLE FILES — Regular Expressions in Linux/Unix
  Section 1: Common Commands That Use Regular Expressions
========================================================

This folder contains sample data files used in the lab exercises.
Each file is designed to work with specific commands and examples
from the lab documentation.

FILE LIST & PURPOSE
-------------------

logfile.txt
  Used with: grep
  Content : System log with INFO / WARNING / ERROR lines
  Try this: grep '^ERROR' logfile.txt
            grep -c 'WARNING' logfile.txt

data.txt
  Used with: grep
  Content : Mixed text — some lines contain 4-digit numbers
  Try this: grep '[0-9]\{4\}' data.txt

file.txt
  Used with: grep -E, awk
  Content : Sentences mentioning cats, dogs, and people named Benson
  Try this: grep -E '(cat|dog)' file.txt
            awk '/^Benson/' file.txt

auth.log
  Used with: grep, grep -E, awk (pipeline)
  Content : SSH authentication events (failed and accepted logins)
  Try this: grep 'Failed password' auth.log
            grep -Eo '[0-9]{1,3}(\.[0-9]{1,3}){3}' auth.log

data.csv
  Used with: awk, grep -E, sed
  Content : Employee records with ID, name, department, salary, rating
  Try this: awk -F',' '{ print $3 }' data.csv
            awk -F',' '$4 > 90000 { print $2, $4 }' data.csv

contacts.txt
  Used with: grep -E, perl
  Content : Contact list with names, emails, and phone numbers
  Try this: grep -Eo '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}' contacts.txt
            perl -nle 'print $1 if /([\w.]+@[\w.]+\.\w{2,})/' contacts.txt

access.log
  Used with: grep -E (IP extraction), awk
  Content : Web server (Apache-style) access log
  Try this: grep -Eo '[0-9]{1,3}(\.[0-9]{1,3}){3}' access.log
            awk '{ print $9 }' access.log   # HTTP status codes

sales.txt
  Used with: awk
  Content : Employee name, department, salary, quarter (space-separated)
  Try this: awk '{ total += $3 } END { print "Total:", total }' sales.txt
            awk '$2 == "Engineering"' sales.txt

report.txt
  Used with: awk (field comparison)
  Content : Project data with ID, name, manager, budget, status, score
  Try this: awk '$6 > 100 { print $0 }' report.txt

httpd.conf
  Used with: sed (in-place editing)
  Content : Sample Apache HTTP server config with commented directives
  Try this: sed 's/^#\(ServerName\)/\1/' httpd.conf
            sed '/^#/d' httpd.conf   # remove all comment lines

system.log
  Used with: grep -i (case-insensitive)
  Content : Kernel and systemd log messages
  Try this: grep -in 'warning' system.log
            grep -c 'WARNING' system.log

server.log
  Used with: less/more, grep, sed
  Content : Application server log with ERROR / WARN / INFO lines
  Try this: grep 'ERROR' server.log
            less server.log   then type  /ERROR  to search inside

========================================================
  HOW TO USE
========================================================

1. Open a terminal and navigate to this folder:
   cd lab_files/

2. Run any of the example commands above.

3. Combine commands in a pipeline:
   grep 'Failed password' auth.log | grep -Eo '[0-9]{1,3}(\.[0-9]{1,3}){3}' | sort | uniq -c | sort -rn

Happy learning!
